---
categories:
  - Edge Case
tags:
  - edge case
  - layout
  - title
---

This post has no title specified in the YAML Front Matter. Jekyll should auto-generate a title from the filename.

For example `2009-09-05-edge-case-no-yaml-title.md` becomes **Edge Case No Yaml Title**.